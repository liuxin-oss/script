1.修改被管理主机主机名，控制节点和被管理主机都要添加对方的域名解析（即配置好hosts文件）
2.使用之前配置被管理主机的sudoers文件
3.在zabbix_server.conf.j2模板中使用的{{ hostvars.node2.ansible_facts.default_ipv4.address }}变量是facts和magic的结合体，
不是单一的facts变量，并且是对主机组的变量，记得修改

